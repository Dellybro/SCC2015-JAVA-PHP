public interface Opolyable {

}