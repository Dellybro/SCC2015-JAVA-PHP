/*

Creator: Travis Delly
Version: 1.0
Purpose: To play Monopoly

Page Instructions - To make new themed game change filename and class name to same name.

*/

public class ComputerOpoly extends Opoly implements Opolyable {
	public static void main(String[] args){
			play();
	}
}
